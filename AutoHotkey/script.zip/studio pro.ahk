﻿#Requires AutoHotkey v2.0

; ==============================================================================
; OSD 配置区 (纯净文字版)
; ==============================================================================
global PosX := "Center"                      ; 水平位置
global PosY := Integer(A_ScreenHeight * 0.8) ; 垂直位置: 默认在屏幕 80% 高度
global FontSize     := 18                    ; 字体大小
global FontWeight   := 700                   ; 字体粗细
global FontAlpha    := 180                   ; 字体透明度
global FontColorOn  := "00FF00"              ; 麦克风开启时的颜色
global FontColorOff := "FF3333"              ; 麦克风静音时的颜色

; ==============================================================================
; 【核心配置】Studio One 内部绝对宏快捷键映射
; ==============================================================================
; 请将这里的值替换为你在 Studio One 里为那两个宏绑定的真实快捷键
global MacroKey_Mute   := "-"                ; 【需修改】例如你给“静音宏”绑定了 [ 键
global MacroKey_Unmute := "="                ; 【需修改】例如你给“取消静音宏”绑定了 ] 键

; ==============================================================================
; 创建 OSD 屏幕提示界面 (纯净文字版)
; ==============================================================================
global textGui := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 +E0x08000000")

; 将背景设为纯黑，然后抠除黑色，剩余文字应用 FontAlpha 透明度
transColor := "000000"
textGui.BackColor := transColor
WinSetTransColor(transColor " " FontAlpha, textGui.Hwnd)

; 设置内边距和字体属性
textGui.MarginX := 30
textGui.MarginY := 15
textGui.SetFont("s" FontSize " w" FontWeight, "Microsoft YaHei")

; 添加文本控件
global osdText := textGui.Add("Text", "w400 Center c" FontColorOn, "UNMUTED")

; 记录 AHK 内部当前状态
global isMuted := false

; ==============================================================================
; 快捷键功能区
; ==============================================================================

; 【快捷键：Ctrl + F10】 -> 切换 Studio Pro 静音状态并显示 OSD
^F10::ToggleStudioProMic()

; ==============================================================================
; 辅助函数区
; ==============================================================================
ToggleStudioProMic() {
    global isMuted
    
    ; 每次按下，翻转 AHK 内部的状态记录
    isMuted := !isMuted

    if (isMuted) {
        ; 状态变为：需要静音 -> 发送“绝对静音”的宏快捷键
        SmartSendToS1(MacroKey_Mute)
        UpdateOSD("MUTED", FontColorOff)
    } else {
        ; 状态变为：需要开启 -> 发送“绝对取消静音”的宏快捷键
        SmartSendToS1(MacroKey_Unmute)
        UpdateOSD("UNMUTED", FontColorOn)
    }
}

; 智能前后台发送函数 (防连按失灵)
SmartSendToS1(keyToSend) {
    if WinActive("ahk_exe Studio Pro.exe") {
        ; 在前台时使用普通的 Send，避免修饰键冲突
        Send(keyToSend) 
    } else {
        ; 在后台时依然使用 ControlSend
        ControlSend(keyToSend, , "ahk_exe Studio Pro.exe")
    }
}

; OSD 更新与显示函数
UpdateOSD(text, color) {
    osdText.SetFont("c" color)
    osdText.Value := text
    
    ; 显示界面，根据配置区设定的坐标显示
    textGui.Show("NoActivate x" PosX " y" PosY)
    
    ; 强制将窗口置于最顶层
    WinSetAlwaysOnTop(1, textGui.Hwnd)
    
    ; 重新设置定时器，1秒（-1000毫秒）后执行隐藏
    SetTimer(HideOSD, -1000)
}

HideOSD() {
    textGui.Hide()
}