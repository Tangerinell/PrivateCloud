﻿#Requires AutoHotkey v2.0

; ==============================================================================
; 临时 OSD 配置区 (居中大字，切换时短暂显示)
; ==============================================================================
global PosX := "Center"                      ; 水平位置
global PosY := Integer(A_ScreenHeight * 0.8) ; 垂直位置: 默认在屏幕 80% 高度
global FontSize     := 18                    ; 字体大小
global FontWeight   := 700                   ; 字体粗细
global FontAlpha    := 170                   ; 字体整体透明度（越大越不透明）
global FontColorOn  := "00FF00"              ; 麦克风开启时的颜色
global FontColorOff := "FF3333"              ; 麦克风静音时的颜色
global OutlineColor := "000000"              ; 文字描边颜色 (推荐纯黑，可消除边缘锯齿)
global OutlineThickness := 1                 ; 临时提示文字的描边厚度 (像素)

; ==============================================================================
; 常驻 OSD 配置区 (角落小字，常驻显示麦克风状态)
; ==============================================================================
global StatusPosX := Integer(A_ScreenWidth * 0.73)  ; 常驻显示水平位置: 屏幕宽度的 75% 处 (右上角)
global StatusPosY := Integer(A_ScreenHeight * 0.9645) ; 常驻显示垂直位置: 屏幕高度的 96% 处
global StatusFontSize := 14                         ; 常驻显示字体大小
global StatusFontWeight := 700                      ; 常驻显示字体粗细
global StatusFontAlpha := 150                       ; 常驻显示字体透明度（越大越不透明）
global StatusOutlineThickness := 1                  ; 常驻提示文字的描边厚度 (像素)
global StatusShow := true                           ; 脚本启动时，默认是否开启常驻显示 (true=开, false=关)

; ==============================================================================
; 【核心配置】Studio One 内部绝对宏快捷键映射
; ==============================================================================
; 请将这里的值替换为你在 Studio One 里为那两个宏绑定的真实快捷键
global MacroKey_Mute   := "-"                ; 【需修改】例如你给“静音宏”绑定了 [ 键
global MacroKey_Unmute := "="                ; 【需修改】例如你给“取消静音宏”绑定了 ] 键

; ==============================================================================
; 创建 OSD 屏幕提示界面 (利用多方向文本重叠实现平滑描边)
; ==============================================================================
; 使用极暗的灰色作为抠像透明色，保留真正的纯黑(000000)用于文字抗锯齿过渡，大幅解决文字边缘发毛的问题
transColor := "010101"
; 8个方向的偏移量，用于生成描边
offsets := [[-1,-1], [0,-1], [1,-1], [-1,0], [1,0], [-1,1], [0,1], [1,1]]

; --- 1. 创建 临时 OSD 界面 ---
global textGui := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 +E0x08000000")
textGui.BackColor := transColor
WinSetTransColor(transColor " " FontAlpha, textGui.Hwnd)
textGui.SetFont("s" FontSize " w" FontWeight, "Microsoft YaHei")

global osdOutlines := []
; 渲染8个方向的描边底层
for index, offset in offsets {
    ox := 30 + offset[1] * OutlineThickness
    oy := 15 + offset[2] * OutlineThickness
    osdOutlines.Push(textGui.Add("Text", "w400 Center BackgroundTrans c" OutlineColor " x" ox " y" oy, "UNMUTED"))
}
; 渲染主文字表层
global osdText := textGui.Add("Text", "w400 Center BackgroundTrans c" FontColorOn " x30 y15", "UNMUTED")

; --- 2. 创建 常驻 OSD 界面 ---
global statusGui := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 +E0x08000000")
statusGui.BackColor := transColor
WinSetTransColor(transColor " " StatusFontAlpha, statusGui.Hwnd)
statusGui.SetFont("s" StatusFontSize " w" StatusFontWeight, "Microsoft YaHei")

global statusOutlines := []
; 渲染8个方向的描边底层
for index, offset in offsets {
    ox := 15 + offset[1] * StatusOutlineThickness
    oy := 10 + offset[2] * StatusOutlineThickness
    statusOutlines.Push(statusGui.Add("Text", "w150 Center BackgroundTrans c" OutlineColor " x" ox " y" oy, "UNMUTED"))
}
; 渲染主文字表层
global statusText := statusGui.Add("Text", "w150 Center BackgroundTrans c" FontColorOn " x15 y10", "UNMUTED")

; 记录 AHK 内部当前状态
global isMuted := false

; 脚本启动时，初始化常驻显示的 UI
if (StatusShow) {
    UpdateStatusGUI()
}

; ==============================================================================
; 快捷键功能区
; ==============================================================================

; 【快捷键：Ctrl + F10】 -> 切换 Studio Pro 静音状态并短暂显示临时 OSD
^F10::ToggleStudioProMic()

; 【快捷键：Alt + 3】 -> 开启或隐藏 常驻的麦克风状态显示
!3::ToggleStatusOSD()


; ==============================================================================
; 辅助函数区
; ==============================================================================
ToggleStudioProMic() {
    global isMuted
    
    ; 先检测 Studio Pro 是否正在运行/窗口是否存在
    if !WinExist("ahk_exe Studio Pro.exe") {
        return ; 如果软件没打开，直接放弃操作
    }

    ; 每次按下，翻转 AHK 内部的状态记录
    isMuted := !isMuted

    if (isMuted) {
        ; 状态变为：需要静音
        SmartSendToS1(MacroKey_Mute)
        UpdateOSD("MUTED", FontColorOff)
    } else {
        ; 状态变为：需要开启
        SmartSendToS1(MacroKey_Unmute)
        UpdateOSD("UNMUTED", FontColorOn)
    }
    
    ; 同步更新常驻显示界面的文字与颜色
    UpdateStatusGUI()
}

; 切换常驻指示器的显示与隐藏
ToggleStatusOSD() {
    global StatusShow
    StatusShow := !StatusShow
    
    if (StatusShow) {
        UpdateStatusGUI() ; 开启显示
    } else {
        statusGui.Hide()  ; 关闭显示
    }
}

; 智能前后台发送函数
SmartSendToS1(keyToSend) {
    if WinActive("ahk_exe Studio Pro.exe") {
        ; 在前台时使用普通的 Send
        Send(keyToSend) 
    } else {
        ; 恢复使用 ControlSend
        SetKeyDelay(10, 30) 
        ControlSend("{Ctrl up}" . keyToSend, , "ahk_exe Studio Pro.exe")
        SetKeyDelay(-1, -1) 
    }
}

; 临时 OSD 更新与显示函数 (1秒后消失)
UpdateOSD(text, color) {
    ; 同步更新所有的描边阴影文字
    for ctrl in osdOutlines {
        ctrl.Value := text
    }
    
    ; 更新表层主文字
    osdText.SetFont("c" color)
    osdText.Value := text
    
    textGui.Show("NoActivate x" PosX " y" PosY)
    WinSetAlwaysOnTop(1, textGui.Hwnd)
    
    SetTimer(HideOSD, -1000)
}

HideOSD() {
    textGui.Hide()
}

; 常驻 OSD 更新与显示函数 (常驻不消失)
UpdateStatusGUI() {
    if (!StatusShow)
        return
        
    newText := isMuted ? "MUTED" : "UNMUTED"
    newColor := isMuted ? FontColorOff : FontColorOn
        
    ; 同步更新所有的描边阴影文字
    for ctrl in statusOutlines {
        ctrl.Value := newText
    }
    
    ; 更新表层主文字
    statusText.SetFont("c" newColor)
    statusText.Value := newText
    
    ; 显示并在屏幕置顶
    statusGui.Show("NoActivate x" StatusPosX " y" StatusPosY)
    WinSetAlwaysOnTop(1, statusGui.Hwnd)
}