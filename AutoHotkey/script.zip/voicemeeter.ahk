#Requires AutoHotkey v2.0
#Include VMR.ahk

Persistent ; 保持脚本运行

; ==============================================================================
; 基础配置区 (Voicemeeter 路径与窗口配置)
; ==============================================================================
global exeName := "voicemeeter8x64.exe"                                ; 主进程名
global appPath := "C:\Program Files (x86)\VB\Voicemeeter\voicemeeter8x64.exe"  ; 安装路径
global titleContains := "Voicemeeter Potato"                           ; 窗口标题包含的关键字
global lastHwnd := 0                                                   ; 记录上次窗口句柄
global vm := ""                                                        ; 存储 VMR 实例对象

; ==============================================================================
; OSD 配置区 (纯净文字版)
; ==============================================================================
global PosX := "Center"                      ; 水平位置
global PosY := Integer(A_ScreenHeight * 0.8) ; 垂直位置: 默认在屏幕 80% 高度
global FontSize     := 18                    ; 字体大小
global FontWeight   := 700                   ; 字体粗细
global FontAlpha    := 180                   ; 字体透明度
global FontColorOn  := "00FF00"              ; 麦克风开启时的颜色
global FontColorOff := "FF3333"              ; 麦克风静音时的颜色

; ==============================================================================
; 初始化 Voicemeeter
; ==============================================================================
try {
    global vm := VMR().Login()
} catch Error as e {
    MsgBox("无法连接到 Voicemeeter，请确保软件已启动。`n`n错误信息: " e.Message, "连接失败", "Iconx")
    ExitApp
}

; ==============================================================================
; 创建 OSD 屏幕提示界面 (纯净文字版)
; ==============================================================================
global textGui := Gui("+AlwaysOnTop -Caption +ToolWindow +E0x20 +E0x08000000")

; 将背景设为纯黑，然后抠除黑色，剩余文字应用 FontAlpha 透明度
transColor := "000000"
textGui.BackColor := transColor
WinSetTransColor(transColor " " FontAlpha, textGui.Hwnd)

; 设置内边距和字体属性
textGui.MarginX := 30
textGui.MarginY := 15
textGui.SetFont("s" FontSize " w" FontWeight, "Microsoft YaHei")

; 添加文本控件
global osdText := textGui.Add("Text", "w400 Center c" FontColorOn, "麦克风已开启")

; ==============================================================================
; 快捷键功能区
; ==============================================================================

; 【快捷键：Ctrl + F10】 -> 切换麦克风状态并显示 OSD
^F10::ToggleMic()

; 【快捷键：Alt + C (!c)】 -> 切换显示/隐藏 Voicemeeter 窗口
!c:: {
    global lastHwnd
    
    ; 优先使用上次记录的窗口句柄（最小化后最可靠）
    if (lastHwnd && WinExist("ahk_id " lastHwnd)) {
        if WinActive("ahk_id " lastHwnd) {
            WinMinimize
        } else {
            WinActivate "ahk_id " lastHwnd
        }
        return
    }
    
    ; 遍历查找已打开的 Voicemeeter 窗口
    foundHwnd := 0
    for hwnd in WinGetList("ahk_exe " exeName) {
        title := WinGetTitle(hwnd)
        if InStr(title, titleContains) {
            foundHwnd := hwnd
            break
        }
    }
    
    if (foundHwnd) {
        lastHwnd := foundHwnd
        if WinActive("ahk_id " foundHwnd) {
            WinMinimize
        } else {
            WinActivate "ahk_id " foundHwnd
        }
        return
    }
    
    ; 完全没打开 → 启动程序
    Run appPath
    
    ; 等待窗口出现并记录句柄
    WinWait "ahk_exe " exeName, , 10
    Sleep 800
    for hwnd in WinGetList("ahk_exe " exeName) {
        title := WinGetTitle(hwnd)
        if InStr(title, titleContains) {
            lastHwnd := hwnd
            WinActivate "ahk_id " hwnd
            break
        }
    }
}

; 【快捷键：Alt + R (!r)】 -> 重启 Voicemeeter 音频引擎
!r:: {
    global vm
    
    try {
        ; 如果尚未初始化或连接丢失，则重新初始化 VMR
        if (!IsObject(vm) || !vm.HasProp("Type") || !vm.Type) {
            SplitPath(appPath, , &vmDir) ; 自动从程序路径提取安装目录
            vm := VMR(vmDir)             ; 传入目录以便 VMR 库能精准定位 DLL
            vm.Login(false)              ; 参数 false: 如果VM没在运行，不强行弹窗
        }
        
        ; 使用 VMR 库的 Command 类执行重启指令
        if (vm.Command.Restart()) {
            ToolTip("VM引擎已重启")
            SetTimer(() => ToolTip(), -2000)
        } else {
            ToolTip("重启指令发送失败")
            SetTimer(() => ToolTip(), -2000)
        }
        
    } catch Error as err {
        ToolTip("无法连接到VM: " err.Message)
        SetTimer(() => ToolTip(), -3000)
        vm := "" ; 连接出错时清空实例，确保下次按键时重试连接
    }
}

; ==============================================================================
; 辅助函数区
; ==============================================================================
ToggleMic() {
    ; 读取 in1 的静音状态作为基准
    currentState := vm.Strip[8].mute
    newState := !currentState
    
    ; 同时设置 in1 (Strip 1) 和 虚拟in3 (Strip 8) 的静音状态
    vm.Strip[1].mute := newState
    vm.Strip[2].mute := newState
    vm.Strip[8].mute := newState

    ; 更改 OSD 的文本和颜色
    if (newState) {
        osdText.SetFont("c" FontColorOff)
        osdText.Value := "IN1 IN2 VIN3 MUTED"
    } else {
        osdText.SetFont("c" FontColorOn)
        osdText.Value := "IN1 IN2 VIN3 UNMUTED"
    }
    
    ; 显示界面，根据配置区设定的坐标显示
    textGui.Show("NoActivate x" PosX " y" PosY)
    
    ; 重新设置定时器，1秒（-1000毫秒）后执行隐藏
    SetTimer(HideOSD, -1000)
}

HideOSD() {
    textGui.Hide()
}